package ljb.board;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class BoardCtl {

	@GetMapping("/home")
	public ModelAndView home() {
		System.out.println("home 요청 처리");
		ModelAndView mv = new ModelAndView("home");
		mv.addObject("result","^^");
		return mv;
	}
}
